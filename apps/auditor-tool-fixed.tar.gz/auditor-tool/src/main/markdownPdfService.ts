import { BrowserWindow } from 'electron';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { app } from 'electron';

interface MarkdownPayload {
    markdown: string;
    signerId: string;
    algorithm: 'RSA-SHA256' | 'ECDSA-P256';
    privateKey: string;
}

interface KeyPair {
    publicKey: string;
    privateKey: string;
}

// Generate default key pairs for different algorithms
function generateDefaultKeyPair(algorithm: string): KeyPair {
    if (algorithm === 'RSA-SHA256') {
        const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
            modulusLength: 2048,
            publicKeyEncoding: { type: 'spki', format: 'pem' },
            privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
        });
        return { publicKey, privateKey };
    } else {
        // ECDSA
        const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', {
            namedCurve: 'prime256v1',
            publicKeyEncoding: { type: 'spki', format: 'pem' },
            privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
        });
        return { publicKey, privateKey };
    }
}

export async function generateProofFromMarkdown(
    payload: MarkdownPayload,
    mainWindow: BrowserWindow
): Promise<{ filePath: string; fileHash: string }> {
    const { markdown, signerId, algorithm, privateKey } = payload;

    // Determine key pair
    let privKey: string;
    let pubKey: string;

    if (privateKey && privateKey !== 'DEFAULT_KEY') {
        // User provided key
        privKey = privateKey;
        try {
            const keyObject = crypto.createPrivateKey(privKey);
            pubKey = crypto.createPublicKey(keyObject).export({ type: 'spki', format: 'pem' }) as string;
        } catch (e) {
            throw new Error('Invalid private key format');
        }
    } else {
        // Generate ephemeral key
        const keyPair = generateDefaultKeyPair(algorithm);
        privKey = keyPair.privateKey;
        pubKey = keyPair.publicKey;
    }

    // Convert Markdown to HTML
    const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Times New Roman', serif; padding: 40px; line-height: 1.6; }
    h1 { color: #0088cc; border-bottom: 2px solid #0088cc; padding-bottom: 10px; }
    h2 { color: #333; margin-top: 30px; }
    code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; }
    pre { background: #f4f4f4; padding: 15px; border-radius: 5px; overflow-x: auto; }
    table { border-collapse: collapse; width: 100%; margin: 20px 0; }
    th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
    th { background-color: #f2f2f2; }
  </style>
</head>
<body>
  ${convertMarkdownToHTML(markdown)}
  <hr style="margin-top: 50px; border: none; border-top: 1px solid #ccc;">
  <p style="font-size: 12px; color: #666;">
    <strong>Signer ID:</strong> ${signerId}<br>
    <strong>Timestamp:</strong> ${new Date().toISOString()}<br>
    <strong>Algorithm:</strong> ${algorithm}
  </p>
</body>
</html>
  `;

    // Use Electron's printToPDF
    const pdfBuffer = await mainWindow.webContents.printToPDF({
        marginsType: 0,
        printBackground: true,
        pageSize: 'A4'
    });

    // Save PDF
    const documentsPath = app.getPath('documents');
    const saveDir = path.join(documentsPath, 'ZeporProofs');
    if (!fs.existsSync(saveDir)) {
        fs.mkdirSync(saveDir, { recursive: true });
    }

    const timestamp = Date.now();
    const fileName = `proof_${signerId}_${timestamp}.pdf`;
    const filePath = path.join(saveDir, fileName);
    fs.writeFileSync(filePath, pdfBuffer);

    // Calculate hash
    const fileHash = crypto.createHash('sha256').update(pdfBuffer).digest('hex');

    // Sign the hash
    const signAlgorithm = algorithm === 'RSA-SHA256' ? 'RSA-SHA256' : 'sha256';
    const sign = crypto.createSign(signAlgorithm);
    sign.update(pdfBuffer);
    const signature = sign.sign(privKey, 'hex');

    // Save metadata and signature
    const metadataPath = filePath + '.meta.json';
    const metadata = {
        signerId,
        timestamp,
        algorithm,
        publicKey: pubKey,
        fileHash,
        signature
    };
    fs.writeFileSync(metadataPath, JSON.stringify(metadata, null, 2));

    return { filePath, fileHash };
}

// Simple Markdown to HTML converter (basic implementation)
function convertMarkdownToHTML(markdown: string): string {
    let html = markdown;

    // Headers
    html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
    html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');

    // Bold
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

    // Italic
    html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');

    // Lists
    html = html.replace(/^\- (.*$)/gim, '<li>$1</li>');
    html = html.replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>');

    // Line breaks
    html = html.replace(/\n/g, '<br>');

    return html;
}
