import { useState } from 'react'
import SimpleMDE from 'react-simplemde-editor'
import 'easymde/dist/easymde.min.css'

const DEFAULT_TEMPLATE = `# Zepor Proof of Reserve Audit Report

## Auditor Information
- **Auditor ID**: [Your ID]
- **Date**: ${new Date().toISOString().split('T')[0]}

## Reserve Details
- **Asset Type**: [e.g., USD, BTC, ETH]
- **Total Amount**: [Amount]
- **Custody Location**: [Location]

## Verification Statement
We hereby certify that the above-mentioned assets are held in custody and have been verified as of the date specified.

---
*This document is cryptographically signed by the auditor.*
`

interface SigningConfig {
  signerId: string
  algorithm: 'RSA-SHA256' | 'ECDSA-P256'
  privateKey: string
}

function App(): JSX.Element {
  const [markdown, setMarkdown] = useState<string>(DEFAULT_TEMPLATE)
  const [config, setConfig] = useState<SigningConfig>({
    signerId: 'AUDITOR-001',
    algorithm: 'RSA-SHA256',
    privateKey: ''
  })
  const [status, setStatus] = useState<string>('')
  const [isProcessing, setIsProcessing] = useState(false)

  const handleGenerate = async () => {
    setIsProcessing(true)
    setStatus('Generating PDF from Markdown...')

    try {
      const payload = {
        markdown,
        signerId: config.signerId,
        algorithm: config.algorithm,
        privateKey: config.privateKey || 'DEFAULT_KEY'
      }

      // @ts-ignore
      const result = await window.api.generateProofFromMarkdown(payload)
      setStatus(`Success! PDF saved to: ${result.filePath}`)
    } catch (error) {
      console.error(error)
      setStatus('Error generating PDF. Check console.')
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif', maxWidth: '900px', margin: '0 auto' }}>
      <h1 style={{ color: '#0088cc' }}>Zepor Auditor Tool</h1>
      <p>Create and sign Proof of Reserve documents</p>

      <div style={{ marginTop: '30px' }}>
        <h3>Markdown Content</h3>
        <SimpleMDE
          value={markdown}
          onChange={setMarkdown}
          options={{
            spellChecker: false,
            placeholder: 'Write your audit report here...',
            minHeight: '300px'
          }}
        />
      </div>

      <div style={{ marginTop: '30px', display: 'flex', flexDirection: 'column', gap: '15px' }}>
        <h3>Signing Configuration</h3>

        <div className="form-group">
          <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Signer ID</label>
          <input
            type="text"
            value={config.signerId}
            onChange={(e) => setConfig({ ...config, signerId: e.target.value })}
            style={{ width: '100%', padding: '8px' }}
          />
        </div>

        <div className="form-group">
          <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Signing Algorithm</label>
          <select
            value={config.algorithm}
            onChange={(e) => setConfig({ ...config, algorithm: e.target.value as any })}
            style={{ width: '100%', padding: '8px' }}
          >
            <option value="RSA-SHA256">RSA-SHA256</option>
            <option value="ECDSA-P256">ECDSA-P256</option>
          </select>
        </div>

        <div className="form-group">
          <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Private Key (PEM format, optional)
          </label>
          <textarea
            value={config.privateKey}
            onChange={(e) => setConfig({ ...config, privateKey: e.target.value })}
            placeholder="-----BEGIN PRIVATE KEY-----&#10;...&#10;-----END PRIVATE KEY-----&#10;&#10;Leave empty to use default key"
            style={{ width: '100%', padding: '8px', minHeight: '100px', fontFamily: 'monospace', fontSize: '12px' }}
          />
          <small style={{ color: '#666' }}>
            If not provided, a default ephemeral key will be used for signing.
          </small>
        </div>

        <button
          onClick={handleGenerate}
          disabled={isProcessing}
          style={{
            marginTop: '20px',
            padding: '12px',
            backgroundColor: isProcessing ? '#cccccc' : '#28a745',
            color: 'white',
            border: 'none',
            cursor: isProcessing ? 'not-allowed' : 'pointer',
            fontSize: '16px',
            fontWeight: 'bold'
          }}
        >
          {isProcessing ? 'Processing...' : 'Generate & Sign PDF'}
        </button>

        {status && (
          <div style={{
            marginTop: '20px',
            padding: '15px',
            backgroundColor: status.includes('Success') ? '#d4edda' : '#f8d7da',
            color: status.includes('Success') ? '#155724' : '#721c24',
            borderRadius: '4px'
          }}>
            {status}
          </div>
        )}
      </div>
    </div>
  )
}

export default App
