import { useState } from 'react'

interface ReserveData {
  amount: number
  currency: string
  date: string
  auditorId: string
}

function App(): JSX.Element {
  const [formData, setFormData] = useState<ReserveData>({
    amount: 1000000,
    currency: 'USD',
    date: new Date().toISOString().split('T')[0],
    auditorId: 'AUD-001'
  })
  const [status, setStatus] = useState<string>('')
  const [isProcessing, setIsProcessing] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleGenerate = async () => {
    setIsProcessing(true)
    setStatus('Generating PDF...')
    try {
      // @ts-ignore
      const result = await window.api.generateProof(formData)
      setStatus(`Success! PDF saved to: ${result.filePath}`)
    } catch (error) {
      console.error(error)
      setStatus('Error generating PDF. Check console.')
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="container" style={{ padding: '20px', fontFamily: 'sans-serif', maxWidth: '600px', margin: '0 auto' }}>
      <h1 style={{ color: '#0088cc' }}>Zepor Auditor Tool</h1>
      <p>Secure Proof of Reserve Generator</p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '15px', marginTop: '30px' }}>
        <div className="form-group">
          <label style={{ display: 'block', marginBottom: '5px' }}>Auditor ID</label>
          <input
            type="text"
            name="auditorId"
            value={formData.auditorId}
            onChange={handleChange}
            style={{ width: '100%', padding: '8px' }}
          />
        </div>

        <div className="form-group">
          <label style={{ display: 'block', marginBottom: '5px' }}>Reserve Amount</label>
          <input
            type="number"
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            style={{ width: '100%', padding: '8px' }}
          />
        </div>

        <div className="form-group">
          <label style={{ display: 'block', marginBottom: '5px' }}>Currency</label>
          <select
            name="currency"
            value={formData.currency}
            onChange={handleChange}
            style={{ width: '100%', padding: '8px' }}
          >
            <option value="USD">USD</option>
            <option value="EUR">EUR</option>
            <option value="BTC">BTC</option>
            <option value="ETH">ETH</option>
          </select>
        </div>

        <div className="form-group">
          <label style={{ display: 'block', marginBottom: '5px' }}>Date</label>
          <input
            type="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            style={{ width: '100%', padding: '8px' }}
          />
        </div>

        <button
          onClick={handleGenerate}
          disabled={isProcessing}
          style={{
            marginTop: '20px',
            padding: '12px',
            backgroundColor: isProcessing ? '#cccccc' : '#28a745',
            color: 'white',
            border: 'none',
            cursor: isProcessing ? 'not-allowed' : 'pointer',
            fontSize: '16px',
            fontWeight: 'bold'
          }}
        >
          {isProcessing ? 'Processing...' : 'Generate & Sign PDF'}
        </button>

        {status && (
          <div style={{
            marginTop: '20px',
            padding: '15px',
            backgroundColor: status.includes('Success') ? '#d4edda' : '#f8d7da',
            color: status.includes('Success') ? '#155724' : '#721c24',
            borderRadius: '4px'
          }}>
            {status}
          </div>
        )}
      </div>
    </div>
  )
}

export default App
