import { ElectronAPI } from '@electron-toolkit/preload'

declare global {
  interface Window {
    electron: ElectronAPI
    api: {
      generateProof: (data: any) => Promise<{ filePath: string; fileHash: string }>
    }
  }
}
